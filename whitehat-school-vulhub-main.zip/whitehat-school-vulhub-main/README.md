# Whitehat School `vulhub` 한글판

> https://github.com/vulhub/vulhub

차세대 보안리더 양성 프로그램 화이트햇 스쿨 1기 과제 제출 Repository

vulhub 을 기반으로 한국어 번역 및 컨텐츠를 추가하는 것을 목표로 공동작업합니다.
